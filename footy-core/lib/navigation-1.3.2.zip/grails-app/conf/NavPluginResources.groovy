modules = {
    'navigation.plugin' {
        resource url:[plugin:'navigation', dir:'css', file:'navigation.css']
    }
}